"use strict";exports.id=933,exports.ids=[933],exports.modules={4933:(a,b,c)=>{c.r(b),c.d(b,{LiteYTEmbed:()=>d});class d extends HTMLElement{constructor(){super(),this.isIframeLoaded=!1,this.isPlaylistThumbnailLoaded=!1,this.setupDom()}static get observedAttributes(){return["videoid","playlistid","videoplay","videotitle"]}connectedCallback(){this.addEventListener("pointerover",()=>d.warmConnections(this),{once:!0}),this.addEventListener("click",()=>this.addIframe())}get videoId(){return encodeURIComponent(this.getAttribute("videoid")||"")}set videoId(a){this.setAttribute("videoid",a)}get playlistId(){return encodeURIComponent(this.getAttribute("playlistid")||"")}set playlistId(a){this.setAttribute("playlistid",a)}get videoTitle(){return this.getAttribute("videotitle")||"Video"}set videoTitle(a){this.setAttribute("videotitle",a)}get videoPlay(){return this.getAttribute("videoplay")||"Play"}set videoPlay(a){this.setAttribute("videoplay",a)}get videoStartAt(){return this.getAttribute("videoStartAt")||"0"}get autoLoad(){return this.hasAttribute("autoload")}get autoPause(){return this.hasAttribute("autopause")}get noCookie(){return this.hasAttribute("nocookie")}get posterQuality(){return this.getAttribute("posterquality")||"hqdefault"}get posterLoading(){return this.getAttribute("posterloading")||"lazy"}get params(){return`start=${this.videoStartAt}&${this.getAttribute("params")}`}set params(a){this.setAttribute("params",a)}set posterQuality(a){this.setAttribute("posterquality",a)}get disableNoscript(){return this.hasAttribute("disablenoscript")}setupDom(){let a=this.attachShadow({mode:"open"}),b="";window.liteYouTubeNonce&&(b=`nonce="${window.liteYouTubeNonce}"`),a.innerHTML=`
      <style ${b}>
        :host {
          --aspect-ratio: var(--lite-youtube-aspect-ratio, 16 / 9);
          --aspect-ratio-short: var(--lite-youtube-aspect-ratio-short, 9 / 16);
          --frame-shadow-visible: var(--lite-youtube-frame-shadow-visible, yes);
          contain: content;
          display: block;
          position: relative;
          width: 100%;
          aspect-ratio: var(--aspect-ratio);
        }

        @media (max-width: 40em) {
          :host([short]) {
            aspect-ratio: var(--aspect-ratio-short);
          }
        }

        #frame, #fallbackPlaceholder, iframe {
          position: absolute;
          width: 100%;
          height: 100%;
          left: 0;
          top: 0;
        }

        #frame {
          cursor: pointer;
        }

        #fallbackPlaceholder, slot[name=image]::slotted(*) {
          object-fit: cover;
          width: 100%;
          height: 100%;
        }

        @container style(--frame-shadow-visible: yes) {
          #frame::before {
            content: '';
            display: block;
            position: absolute;
            top: 0;
            background-image: linear-gradient(180deg, #111 -20%, transparent 90%);
            height: 60px;
            width: 100%;
            z-index: 1;
          }
        }

        #playButton {
          width: 68px;
          height: 48px;
          background-color: transparent;
          background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 68 48"><path d="M66.52 7.74c-.78-2.93-2.49-5.41-5.42-6.19C55.79.13 34 0 34 0S12.21.13 6.9 1.55c-2.93.78-4.63 3.26-5.42 6.19C.06 13.05 0 24 0 24s.06 10.95 1.48 16.26c.78 2.93 2.49 5.41 5.42 6.19C12.21 47.87 34 48 34 48s21.79-.13 27.1-1.55c2.93-.78 4.64-3.26 5.42-6.19C67.94 34.95 68 24 68 24s-.06-10.95-1.48-16.26z" fill="red"/><path d="M45 24 27 14v20" fill="white"/></svg>');
          z-index: 1;
          border: 0;
          border-radius: inherit;
        }

        #playButton:before {
          content: '';
          border-style: solid;
          border-width: 11px 0 11px 19px;
          border-color: transparent transparent transparent #fff;
        }

        #playButton,
        #playButton:before {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate3d(-50%, -50%, 0);
          cursor: inherit;
        }

        /* Post-click styles */
        .activated {
          cursor: unset;
        }

        #frame.activated::before,
        #frame.activated > #playButton {
          display: none;
        }
      </style>
      <div id="frame">
        <picture>
          <slot name="image">
            <source id="webpPlaceholder" type="image/webp">
            <source id="jpegPlaceholder" type="image/jpeg">
            <img id="fallbackPlaceholder" referrerpolicy="origin" loading="lazy">
          </slot>
        </picture>
        <button id="playButton" part="playButton"></button>
      </div>
    `,this.domRefFrame=a.querySelector("#frame"),this.domRefImg={fallback:a.querySelector("#fallbackPlaceholder"),webp:a.querySelector("#webpPlaceholder"),jpeg:a.querySelector("#jpegPlaceholder")},this.domRefPlayButton=a.querySelector("#playButton")}setupComponent(){0===this.shadowRoot.querySelector("slot[name=image]").assignedNodes().length&&this.initImagePlaceholder(),this.domRefPlayButton.setAttribute("aria-label",`${this.videoPlay}: ${this.videoTitle}`),this.setAttribute("title",`${this.videoPlay}: ${this.videoTitle}`),(this.autoLoad||this.isYouTubeShort()||this.autoPause)&&this.initIntersectionObserver(),this.disableNoscript||this.injectSearchNoScript()}attributeChangedCallback(a,b,c){b!==c&&("playlistid"===a&&null!==b&&b!==c&&(this.isPlaylistThumbnailLoaded=!1),this.setupComponent(),this.domRefFrame.classList.contains("activated")&&(this.domRefFrame.classList.remove("activated"),this.shadowRoot.querySelector("iframe").remove(),this.isIframeLoaded=!1))}injectSearchNoScript(){let a=document.createElement("noscript");this.prepend(a),a.innerHTML=this.generateIframe()}generateIframe(a=!1){let b,c=+!a,d=this.autoPause?"&enablejsapi=1":"",e=this.noCookie?"-nocookie":"";return b=this.playlistId?`?listType=playlist&list=${this.playlistId}&`:`${this.videoId}?`,this.isYouTubeShort()&&(this.params=`loop=1&mute=1&modestbranding=1&playsinline=1&rel=0&enablejsapi=1&playlist=${this.videoId}`,c=1),`
<iframe credentialless frameborder="0" title="${this.videoTitle}"
  referrerpolicy="strict-origin-when-cross-origin"
  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen
  src="https://www.youtube${e}.com/embed/${b}autoplay=${c}${d}&${this.params}"
></iframe>`}addIframe(a=!1){if(!this.isIframeLoaded){let b=this.generateIframe(a);this.domRefFrame.insertAdjacentHTML("beforeend",b),this.domRefFrame.classList.add("activated"),this.isIframeLoaded=!0,this.attemptShortAutoPlay(),this.dispatchEvent(new CustomEvent("liteYoutubeIframeLoaded",{detail:{videoId:this.videoId},bubbles:!0,cancelable:!0}))}}initImagePlaceholder(){this.playlistId&&!this.videoId?this.loadPlaylistThumbnail():this.testPosterImage(),this.domRefImg.fallback.setAttribute("aria-label",`${this.videoPlay}: ${this.videoTitle}`),this.domRefImg?.fallback?.setAttribute("alt",`${this.videoPlay}: ${this.videoTitle}`)}async loadPlaylistThumbnail(){if(!this.isPlaylistThumbnailLoaded){this.isPlaylistThumbnailLoaded=!0;try{let a=`https://www.youtube.com/oembed?url=https://www.youtube.com/playlist?list=${this.playlistId}&format=json`,b=await fetch(a);if(!b.ok)throw Error(`Failed to fetch playlist thumbnail: ${b.status}`);let c=await b.json();if(c.thumbnail_url){let a=c.thumbnail_url,b=a.match(/\/vi\/([^\/]+)\//);if(b){let a=b[1];this.loadThumbnailImages(a)}else this.domRefImg.fallback.src=a,this.domRefImg.fallback.loading=this.posterLoading}}catch(a){console.warn("Failed to load playlist thumbnail:",a)}}}loadThumbnailImages(a){let b=`https://i.ytimg.com/vi_webp/${a}/${this.posterQuality}.webp`;this.domRefImg.webp.srcset=b;let c=`https://i.ytimg.com/vi/${a}/${this.posterQuality}.jpg`;this.domRefImg.jpeg.srcset=c,this.domRefImg.fallback.src=c,this.domRefImg.fallback.loading=this.posterLoading}async testPosterImage(){setTimeout(()=>{let a=`https://i.ytimg.com/vi_webp/${this.videoId}/${this.posterQuality}.webp`,b=new Image;b.fetchPriority="low",b.referrerPolicy="origin",b.src=a,b.onload=async a=>{let b=a.target;b?.naturalHeight==90&&b?.naturalWidth==120&&(this.posterQuality="hqdefault"),this.loadThumbnailImages(this.videoId)}},100)}initIntersectionObserver(){new IntersectionObserver((a,b)=>{a.forEach(a=>{a.isIntersecting&&!this.isIframeLoaded&&(d.warmConnections(this),this.addIframe(!0),b.unobserve(this))})},{root:null,rootMargin:"0px",threshold:0}).observe(this),this.autoPause&&new IntersectionObserver((a,b)=>{a.forEach(a=>{1!==a.intersectionRatio&&this.shadowRoot.querySelector("iframe")?.contentWindow?.postMessage('{"event":"command","func":"pauseVideo","args":""}',"*")})},{threshold:1}).observe(this)}attemptShortAutoPlay(){this.isYouTubeShort()&&setTimeout(()=>{this.shadowRoot.querySelector("iframe")?.contentWindow?.postMessage('{"event":"command","func":"playVideo","args":""}',"*")},2e3)}isYouTubeShort(){return""===this.getAttribute("short")&&window.matchMedia("(max-width: 40em)").matches}static addPrefetch(a,b){let c=document.createElement("link");c.rel=a,c.href=b,c.crossOrigin="true",document.head.append(c)}static warmConnections(a){d.isPreconnected||window.liteYouTubeIsPreconnected||(d.addPrefetch("preconnect","https://i.ytimg.com/"),d.addPrefetch("preconnect","https://s.ytimg.com"),a.noCookie?d.addPrefetch("preconnect","https://www.youtube-nocookie.com"):(d.addPrefetch("preconnect","https://www.youtube.com"),d.addPrefetch("preconnect","https://www.google.com"),d.addPrefetch("preconnect","https://googleads.g.doubleclick.net"),d.addPrefetch("preconnect","https://static.doubleclick.net")),d.isPreconnected=!0,window.liteYouTubeIsPreconnected=!0)}}d.isPreconnected=!1,customElements.define("lite-youtube",d)}};